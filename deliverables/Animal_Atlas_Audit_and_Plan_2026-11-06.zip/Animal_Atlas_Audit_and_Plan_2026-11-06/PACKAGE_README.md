# Animal Atlas audit and revised plan

Start with docs/BUILD_PLAN.md, then docs/audits/AUDIT_AND_REVISED_BUILD_PLAN.md.

This documentation handoff contains the 21-area replacement plan, three independent Astra audits, active agent/C++ rules and rationale, retained isolated evidence, proposed UI contract, full feature brief and Direction H images. The design brief is under deliverables/Animal_Atlas_Direction_H_Design_Handoff. Relative document and image layout is preserved.

This is a documentation package, not an application or full source checkout. Code-line links in the dated audit reports refer to the original audited repository. Audit probes/build commands run in that repository, not in this documentation archive. No private collection database, API token, user recording, build product or paid dependency is included.

No audio engine, GUI, plug-in or release qualification is implied. The original issued Direction H v1 ZIP remains unchanged; this is the updated plan/audit handoff.
